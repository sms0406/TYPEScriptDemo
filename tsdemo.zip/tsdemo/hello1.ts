console.log("Hello and Welcome to TypeScript");
