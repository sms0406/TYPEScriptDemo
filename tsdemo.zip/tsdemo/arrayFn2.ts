let  manufacturers:any[] = [
    { "id": "Samsung", "checked": false },
    { "id": "Motorola", "checked": false },
    { "id": "Apple", "checked": false },
    { "id": "Sony", "checked": false }
];
console.log("1. Displaying a message using forEach():");
function display(){
    console.log("Products to display...");
}
manufacturers.forEach(display);
console.log("2. Available Products using: forEach() array function:");
manufacturers.forEach( function(manufacturer) {
    console.log(manufacturer);
});

manufacturers = ["samsung","motorola","apple","sony"];

console.log("====== Simple map() example =========");
function display_uppercase(manufacturer:string) {
    return manufacturer.toUpperCase();
}
let manufacturers_uppercase:string[] = manufacturers.map(display_uppercase);
console.log(manufacturers_uppercase);

console.log("====== Simple filter() example =========");
function filterManufacturerByLength(val: string) {
    if (val.length > 5) return true;
}
let filtered_manufacturers: string[] = manufacturers.filter(filterManufacturerByLength);
console.log(filtered_manufacturers);


// console.log("====== Simple find() example =========");
// EXAMPLE TO DEMOSTRATE THE USE OF find() built in function ----> This code should be executed in IDE using --target es6 option

/* function findManufacturer(manufacturer: string) {
     if (manufacturer.length > 5)  return true;
 }
 let foundManufacturer: string = manufacturers.find(findManufacturer);
 console.log(foundManufacturer); */
