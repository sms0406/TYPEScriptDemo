
// Use of arrow functions
let manufacturers = [{ "id": "Samsung","price":15000 },
        { "id": "Microsoft","price":20000 },
        { "id": "Apple","price":40000  },
        { "id": "Micromax","price":10000  }
    ];
let test;
let myFunction = () => {
  test = manufacturers.filter((manufacturer)=>manufacturer.price>=20000);
}
myFunction();
console.log("The filtered array is");
for (let i = 0; i < test.length; i++) {
    console.log(test[i].id);
}


// chaining of array functions using arrow function syntax
let subjects: string[] = ["Mathematics-70", "Science-67", "English-88", "Geography-62", "ComputerSc-55"];
subjects.map(value => value.toUpperCase())
    .filter(subjects => parseInt(subjects.substr(-2, 2)) > 65)
    .forEach(sub => console.log(sub));