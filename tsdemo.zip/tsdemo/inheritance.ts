
class Product{
	public productId:number;
	constructor(productId:number){
		this.productId=productId;		
	}	
	getProduct():void{
		console.log("ProductID "+ this.productId);
}}
class Gadget extends Product{
	constructor(public productName:string,productId:number){
		super(productId);
	}	
	getProduct():void{
		super.getProduct();
		console.log("ProductID "+ this.productId+" ProductName "+this.productName);
	}
}
var g=new Gadget("Tablet",1234);
g.getProduct();