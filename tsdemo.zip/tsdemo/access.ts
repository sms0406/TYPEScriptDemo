class Product {
    private productId: number;
    public productName: string;
    public productCategory: string;
    constructor(productId: number, productName, productCategory) {
        this.productId = productId;
        this.productName = productName;
        this.productCategory = productCategory;
    }
    getProductId() {
        return "The productId is " + this.productId;
    }
}

let prod1 = new Product(1001, 'Moto G6plus', 'Mobile');
// As getProductId() method is implemented inside the class Product thus productId is accessible.
console.log(prod1.getProductId());
console.log(prod1.productName);
console.log(prod1.productCategory);
// This would throw an error as we cannot access private properties outside the class
// console.log(prod1.productId);