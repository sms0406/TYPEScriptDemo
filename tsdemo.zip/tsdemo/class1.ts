
// Product is a class consisting of a property productId
class Product{
	productId:number;
	// constructor takes a parameter productId which must be passed while creating an instance of the class
	constructor(productId:number){ 
		this.productId=productId;		
	}
    // getProductId() is a method that displays the productId of the instance created	
	getProductId():string{
          return "product id is "+this.productId;
	}
}

var product:Product = new Product(1234);
console.log(product.getProductId());