class Product {
    static productName: string;

    static getProductDetails(): string {
        return "Product Name is " + Product.productName;
    }

    getProduct(): string {
        return "Product Name is " + Product.productName;
    }
}

Product.productName = 'Tablet';
console.log(Product.productName);
console.log(Product.getProductDetails());

let prod1 = new Product();
// static properties cannot be accessed using object name
// console.log(prod1.productName);